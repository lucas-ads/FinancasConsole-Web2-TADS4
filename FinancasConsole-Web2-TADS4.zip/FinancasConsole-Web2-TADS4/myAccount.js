const fs = require("fs");
const path = require("path");

const chalk = require("chalk");
const inquirer = require("inquirer");

var caminhoUsuario;
var usuario;

var voltarMenuPrincipal;

function run(username, funcaoMenuPrincipal) {
  const caminho = path.join("contas", username + ".json");

  if (fs.existsSync(caminho)) {
    caminhoUsuario = caminho;
    usuario = username;
    voltarMenuPrincipal = funcaoMenuPrincipal;
    dashboard();
  } else {
    throw new Exception("Usuário não existe!");
  }
}

function dashboard() {
  inquirer
    .prompt([
      {
        type: "list",
        name: "opcao",
        message: "Selecione a opção desejada:",
        choices: ["Consultar Saldo", "Depositar", "Sacar", "Sair"],
      },
    ])
    .then((respostas) => {
      const resp = respostas["opcao"];

      if (resp === "Consultar Saldo") {
        consultaSaldo();
      } else if (resp === "Depositar") {
        deposita();
      } else if (resp === "Sacar") {
        saca();
      } else {
        voltarMenuPrincipal();
      }
    })
    .catch((err) => {
      console.log(err);
      voltarMenuPrincipal();
    });
}

function consultaSaldo() {
  console.log("### Consultando saldo ###");

  const content = fs.readFileSync(`./contas/${usuario}.json`, "utf8");
  const conteudoSaldo = JSON.parse(content);
  const dinheiro = conteudoSaldo.monetario

  console.log(chalk.bgGreen.white(`Você tem um total de ${dinheiro}R$`))

  dashboard()
}

function deposita() {
  console.log("### Depositando ###");
  inquirer
    .prompt([
      {
        type: "number",
        name: "deposito",
        message:
          "Informe a quantidade de dinheiro a ser depositado (somente números):",
      },
    ])
    .then((respostas) => {
      const deposito = respostas["deposito"];

      if (!deposito) {
        console.log(chalk.bgRed.black("Informe a quantidade!"));
        return;
      } else if (deposito == 0){
        console.log(chalk.bgRed.black("Você não pode depositar 0 reais!"));
        return
      }

      const caminho = path.join("contas", `${usuario}.json`);
      const conteudo = fs.readFileSync(caminho, "utf8");
      const dadosConta = JSON.parse(conteudo);

      dadosConta.monetario += deposito;

      fs.writeFileSync(caminho, JSON.stringify(dadosConta));

      console.log(chalk.bgGreen.white("Depósito realizado com sucesso!"));

      dashboard();
    })
    .catch((err) => console.log(err));
}

function saca() {
  console.log("### Sacando ###");

  inquirer
    .prompt([
      {
        type: "number",
        name: "saque",
        message:
          "Informe a quantidade de dinheiro a ser sacado (somente números):",
      },
    ])
    .then((respostas) => {
      const saque = respostas["saque"];

      if (!saque) {
        console.log(chalk.bgRed.black("Informe a quantidade!"));
        return;
      }

      const caminho = path.join("contas", `${usuario}.json`);
      const conteudo = fs.readFileSync(caminho, "utf8");
      const dadosConta = JSON.parse(conteudo);

      if (saque > dadosConta.monetario) {
        console.log(chalk.bgRed.black("O saque é maior do que o seu dinheiro atual."));
        return;
      }

      dadosConta.monetario -= saque;

      fs.writeFileSync(caminho, JSON.stringify(dadosConta));

      console.log(chalk.bgGreen.white("Saque realizado com sucesso!"));

      dashboard();
    })
    .catch((err) => console.log(err));
}

  module.exports = run;