Atividade prática: Concluir a aplicação de exemplo, implementando as funcionalidades "consultar saldo", "sacar" e "depositar" no arquivo myAccount.js.

Para desenvolver esta atividade crie um fork deste repositório e evolua a aplicação utilizando tal fork.
Em sua máquina, quando estiver com o código baixado, não se esqueça de executar o comando "npm install" para que os módulos especificados no package.json sejam baixados para a pasta node_modules em seu projeto.
